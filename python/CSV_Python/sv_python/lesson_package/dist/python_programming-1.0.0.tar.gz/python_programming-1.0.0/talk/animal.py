from tools import utils
def bite():
    return 'bite'

def barking():
    return utils.say_twice('barking')