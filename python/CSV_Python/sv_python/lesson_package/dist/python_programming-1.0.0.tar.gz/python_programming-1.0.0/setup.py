from distutils.core import setup

setup(
    name= 'python_programming',
    version= '1.0.0',
    packages= ['talk', 'tools'],
    url= '',
    license= 'Free',
    author= 'chiho',
    author_email='',
    description='sample package'
)